import os
import google.generativeai as genai

# Set the API key
api_key = 'AIzaSyBKgHIE7PF95yANGrq3SpmbusDgEhgCnE8'
os.environ['API_KEY'] = api_key

# Configure the API with the API key
genai.configure(api_key=os.environ["API_KEY"])

import google.generativeai as gemini
from langchain import PromptTemplate


# Define the prompt template
template = "You are a helpful assistant. Answer the following question: {question}"

# Create a PromptTemplate object
prompt = PromptTemplate(template=template, input_variables=["question"])

# Define your question
question = "What are the benefits of using intelligent agents?"

# Generate the prompt using the template
formatted_prompt = prompt.format(question=question)

# Directly call the Google Gemini API
try:
    # Call the generate_text method and get the response object
    response = gemini.generate_text(prompt=formatted_prompt)

    # Access the 'result' attribute or key from the response
    generated_text = response.result
    print("Generated Response:", generated_text)
except Exception as e:
    print(f"Error: {e}")
