import os

GOOGLE_API_KEY = "your-google-gemni-api-key"  # add your GOOGLE API key here
os.environ["GOOGLE_API_KEY"] = GOOGLE_API_KEY


from llama_index.llms.gemini import Gemini
import google.generativeai as genai

# Configure the API with the API key
genai.configure(api_key=os.environ["GOOGLE_API_KEY"])

# Define the correct model path
model_path = "models/gemini-1.5-flash"

# Initialize the Gemini LLM with the correct model path
gemini_llm = Gemini(model=model_path)

# Define a function to generate text using LlamaIndex with the updated model
def generate_text(prompt):
    try:
        # Use the Gemini LLM to complete the prompt
        response = gemini_llm.complete(prompt)
        # Return the generated text
        return response.text
    except Exception as e:
        return f"An error occurred: {str(e)}"

# Define the prompt
prompt = "Write a text about a intelligent agents"

# Generate the response
response = generate_text(prompt)
print("Response from Gemini API:", response)