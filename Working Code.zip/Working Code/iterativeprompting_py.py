import os
import google.generativeai as genai

# Set the API key
api_key = 'AIzaSyBKgHIE7PF95yANGrq3SpmbusDgEhgCnE8'
os.environ['API_KEY'] = api_key

# Configure the API with the API key
genai.configure(api_key=os.environ["API_KEY"])

import re

def generate_mc_question(question_number):
    # Define the prompt
    prompt = (
        f"Generate a multiple-choice question about intelligent agents in the following format:\n"
        f"Q{question_number}: [Question Text]\n"
        f"Options:\n"
        f"(A) Option 1\n"
        f"(B) Option 2\n"
        f"(C) Option 3\n"
        f"(D) Option 4\n"
        f"Provide the correct answer option in the format: Answer: (X) Option X\n"
        f"Do not repeat the question number in the options or answer."
    )

    # Generate text using the API
    response = genai.generate_text(prompt=prompt)
    answer_text = response.result if hasattr(response, 'result') else response['generated_text']

    # Clean the output to remove duplicate question numbers
    # Example regex to remove duplicate "Q1: "
    cleaned_text = re.sub(r'(Q\d+:)\s+\1\s+', r'\1 ', answer_text)

    return cleaned_text.strip()

# Number of questions to generate
num_questions = 3  # Adjust as needed

for i in range(1, num_questions + 1):
    question_text = generate_mc_question(i)
    print(f"Q{i}: {question_text}\n")