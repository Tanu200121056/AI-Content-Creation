import streamlit as st
import os
from llama_index.llms.gemini import Gemini
import streamlit as st
import os
from llama_index.llms.gemini import Gemini
import google.generativeai as genai

# Set the Google API key
GOOGLE_API_KEY = "AIzaSyBKgHIE7PF95yANGrq3SpmbusDgEhgCnE8"  # Add your Google API key here
os.environ["GOOGLE_API_KEY"] = GOOGLE_API_KEY

# Print API key to verify it's set correctly (remove in production)
st.write(f"API Key: {os.environ.get('GOOGLE_API_KEY')}")

# Configure the API with the API key
genai.configure(api_key=os.environ["GOOGLE_API_KEY"])

# Define the correct model path
model_path = "models/gemini-1.5-flash"

# Initialize the Gemini LLM with the correct model path
try:
    gemini_llm = Gemini(model=model_path)
except Exception as e:
    st.error(f"Failed to initialize Gemini model: {e}")

# Define a function to generate text using LlamaIndex with the updated model
def generate_text(prompt):
    try:
        # Use the Gemini LLM to complete the prompt
        response = gemini_llm.complete(prompt)
        # Return the generated text
        return response.text
    except Exception as e:
        return f"An error occurred: {str(e)}"

# Streamlit app
st.title("Question Answer Generator")

# Input for the question
question = st.text_input("Enter your question:")

if st.button("Generate Answer"):
    if question:
        # Generate the response
        response = generate_text(question)
        st.write("Response from Gemini API:", response)
    else:
        st.warning("Please enter a question.")
