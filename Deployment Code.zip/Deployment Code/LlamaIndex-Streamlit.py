import streamlit as st
import os
from llama_index.llms.gemini import Gemini
import google.generativeai as genai

# Set the Google API key
GOOGLE_API_KEY = "AIzaSyBKgHIE7PF95yANGrq3SpmbusDgEhgCnE8"  # Add your Google API key here
os.environ["GOOGLE_API_KEY"] = GOOGLE_API_KEY

# Configure the API with the API key
genai.configure(api_key=os.environ["GOOGLE_API_KEY"])

# Define the correct model path
model_path = "models/gemini-1.5-flash"

# Initialize the Gemini LLM with the correct model path
try:
    gemini_llm = Gemini(model=model_path)
except Exception as e:
    st.error(f"Failed to initialize Gemini model: {e}")

# Define a function to generate text using LlamaIndex with the updated model
def generate_text(prompt):
    try:
        # Use the Gemini LLM to complete the prompt
        response = gemini_llm.complete(prompt)
        # Return the generated text
        return response.text
    except Exception as e:
        return f"An error occurred: {str(e)}"

# Streamlit app
st.title("Topic-Based Question and Answer Generator")

# Input for the topic
topic = st.text_input("Enter a topic:")

# Number of questions to generate
num_questions = st.number_input("Number of questions to generate:", min_value=1, max_value=10, value=3)

if st.button("Generate Questions and Answers"):
    if topic:
        questions = []
        answers = []
        
        for i in range(num_questions):
            # Generate a question based on the topic
            question_prompt = f"Generate a question about the topic: {topic}"
            generated_question = generate_text(question_prompt)
            
            if generated_question:
                questions.append(generated_question)
                
                # Generate an answer for the generated question
                answer_prompt = f"Answer the following question: {generated_question}"
                generated_answer = generate_text(answer_prompt)
                answers.append(generated_answer)
            else:
                st.warning(f"Failed to generate question {i+1}.")
        
        # Display all questions and answers
        for idx, (question, answer) in enumerate(zip(questions, answers)):
            st.write(f"**Question {idx+1}:** {question}")
            st.write(f"**Answer {idx+1}:** {answer}")
            st.write("---")
    else:
        st.warning("Please enter a topic.")
