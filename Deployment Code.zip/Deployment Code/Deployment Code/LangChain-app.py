import streamlit as st
import os
import google.generativeai as genai

# Set the API key
api_key = 'your-google-gemini-api-key' # use your google gemini api key
os.environ['API_KEY'] = api_key

# Configure the API with the API key
genai.configure(api_key=os.environ["API_KEY"])

# Streamlit app
st.title("Intelligent Agent Q&A")

# Input for the question
question = st.text_input("Enter your question:")

if st.button("Generate Answer"):
    if question:
        try:
            # Generate the prompt
            formatted_prompt = f"You are a helpful assistant. Answer the following question: {question}"

            # Call the Google Gemini API
            response = genai.generate_text(prompt=formatted_prompt)

            # Access the 'result' attribute or key from the response
            generated_text = response.result
            st.write("Generated Answer:", generated_text)
        except Exception as e:
            st.error(f"Error: {e}")
    else:
        st.warning("Please enter a question.")
