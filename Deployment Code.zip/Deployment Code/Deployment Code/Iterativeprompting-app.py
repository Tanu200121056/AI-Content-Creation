import streamlit as st
import google.generativeai as genai
import os
import re

# Set the API key
api_key = 'your-google-gemini-api-key' # Use your google gemini api key
os.environ['API_KEY'] = api_key

# Configure the API with the API key
genai.configure(api_key=os.environ["API_KEY"])

def generate_mc_question(question_number):
    # Define the prompt with a clear format request
    prompt = (
        f"Generate a multiple-choice question about intelligent agents in the following format:\n\n"
        f"Q{question_number}: [Question Text]\n"
        f"Options:\n"
        f"(A) Option 1\n"
        f"(B) Option 2\n"
        f"(C) Option 3\n"
        f"(D) Option 4\n"
        f"Answer: (X) Option X\n\n"
        f"Please follow this exact format and do not include any additional text or variations."
    )

    # Generate text using the API
    response = genai.generate_text(prompt=prompt)
    
    # Ensure correct attribute or key is used based on response format
    if hasattr(response, 'result'):
        answer_text = response.result
    elif 'generated_text' in response:
        answer_text = response['generated_text']
    else:
        answer_text = str(response)  # Fallback if the response is not in expected format
    
    # Debugging: Print raw response to understand structure
    st.write("Raw API Response:")
    st.write(answer_text)

    # Clean the output to format correctly
    # Remove excessive whitespace and potential unwanted characters
    cleaned_text = re.sub(r'\s+', ' ', answer_text).strip()
    
    # Optionally, enforce a specific format if needed
    # For example, ensure no extra text is included
    cleaned_text = re.sub(r'(Q\d+:)\s+(Q\d+:)', r'\1', cleaned_text)  # Remove duplicate question number if present

    return cleaned_text.strip()

# Initialize the Streamlit app
st.title("Multiple-Choice Question Generator")

# Number of questions to generate
num_questions = st.number_input("Number of questions to generate:", min_value=1, max_value=10, value=3)

# Button to generate questions
if st.button("Generate Questions"):
    st.write("Generating questions...")
    
    for i in range(1, num_questions + 1):
        question_text = generate_mc_question(i)
        st.subheader(f"Question {i}")
        st.write(question_text)
    
    st.success("Question generation complete!")
